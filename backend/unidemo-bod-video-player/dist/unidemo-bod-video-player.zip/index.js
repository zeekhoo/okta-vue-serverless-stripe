exports.handler = function(event, context, callback) {
    const response = {
        statusCode: 200,
        body: "ok",
        isBase64Encoded: false,
        headers: {
            "Access-Control-Allow-Origin": "*"
        }
    };
    callback(null, response);
}